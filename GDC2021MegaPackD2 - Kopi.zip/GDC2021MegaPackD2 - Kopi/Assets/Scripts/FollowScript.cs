using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowScript : MonoBehaviour
{
    public GameObject tank;
    public float moveSpeed;


    Transform followerTransform;



    private void Start()
    {
        followerTransform = gameObject.GetComponent<Transform>();
    }


    private void Update()
    {
        Follow();
    }



    void Follow()
    {
        // Finder afstanden og retningen til tanken.
        Vector3 direction = tank.GetComponent<Transform>().position - followerTransform.position;
        Vector3 movement = direction.normalized * moveSpeed;

        gameObject.GetComponent<Rigidbody>().velocity = new Vector3(movement.x, gameObject.GetComponent<Rigidbody>().velocity.y, movement.z);

        //Kig p� tanken

        followerTransform.LookAt(tank.GetComponent<Transform>().position);
    }
}
