using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TankScript : MonoBehaviour
{
    public float speed;
    public float RotateSpeed;
    public float bulletSpeed;
    public float reloadTime;
    public float jumpForce;

    public GameObject bulletObj;


    Transform trans;
    Rigidbody tankRB;


    private void OnCollisionEnter(Collision collision)
    {
        bool isHitByEnemy = collision.gameObject.tag == "Enemy";
        if (isHitByEnemy)
        {
            SceneManager.LoadScene(1);
        }
    }



    float timeLastFired;

    // Start is called before the first frame update
    void Start()
    {
        trans = gameObject.GetComponent<Transform>();
        tankRB = gameObject.GetComponent<Rigidbody>();

        timeLastFired = 0;

        Physics.IgnoreLayerCollision(6, 7, true);       
    }

 

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0)){

            bool reloadTimeHasPassed = Time.time >= timeLastFired + reloadTime;

            if (reloadTimeHasPassed)
            {
                Shoot();
            }
        }

        MoveHandler();
        JumpHandler();
    }


    void MoveHandler() {

        if (Input.GetKey("w"))
        {
            tankRB.velocity = gameObject.GetComponent<Transform>().forward * speed;
        }
        if (Input.GetKey("d"))
        {
            tankRB.AddTorque(new Vector3(0, 1, 0) * RotateSpeed);
        }
        if (Input.GetKey("a"))
        {
            tankRB.AddTorque(new Vector3(0, -1, 0) * RotateSpeed);
        }


        /* Transform.translate movement

        if (Input.GetKey("w"))
        {
            Vector3 direction = gameObject.GetComponent<Transform>().forward;
            tankTransform.Translate(direction, Space.Self);
        }
        if (Input.GetKey("d"))
        {
            tankTransform.Rotate(new Vector3(0, 20, 0));
        }
        if (Input.GetKey("a"))
        {
            tankTransform.Rotate(new Vector3(0, -20, 0));
        }
        */
    }


    public void Shoot()
    {
        timeLastFired = Time.time;

        GameObject bullet = Instantiate(bulletObj, trans.position, trans.rotation);
        bullet.GetComponent<Rigidbody>().velocity = trans.forward * bulletSpeed;
    }




    public void JumpHandler()
    {
        Vector3 rayOrigin = trans.position - trans.up * 0.5f;
        bool isOnGround = Physics.Raycast(rayOrigin, -trans.up, 0.2f);
        Debug.DrawRay(rayOrigin, -trans.up * 200f, Color.blue);

        if (isOnGround && Input.GetButton("Jump")){
            tankRB.AddForce(Vector3.up * jumpForce);
        }
    }
}
