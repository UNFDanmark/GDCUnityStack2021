using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    private void Awake()
    {
        GameObject[] gameManager = GameObject.FindGameObjectsWithTag("GameManager");

        bool isFirstManager = gameManager.Length == 1;

        if (isFirstManager)
        {
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        bool menuButtonPressed = Input.GetButtonDown("Menu");

        bool menu�sPresent = false;


        if (menuButtonPressed && !menu�sPresent)
        {
            menu�sPresent = true;
            StartCoroutine(OpenMenu());
            
        }
        else if (menuButtonPressed)
        {
            menu�sPresent = false;
            StartCoroutine(CloseMenu());
        }

        
    }

    IEnumerator OpenMenu()
    {

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(2, LoadSceneMode.Additive);

        // Wait until the asynchronous scene fully loads
        while (!asyncLoad.isDone)
        {
            yield return null;
        }
    }


    IEnumerator CloseMenu()
    {
        // The Application loads the Scene in the background as the current Scene runs.
        // This is particularly good for creating loading screens.
        // You could also load the Scene by using sceneBuildIndex. In this case Scene2 has
        // a sceneBuildIndex of 1 as shown in Build Settings.

        AsyncOperation asyncLoad = SceneManager.UnloadSceneAsync(2);

        // Wait until the asynchronous scene fully loads
        while (!asyncLoad.isDone)
        {
            yield return null;
        }
    }
}
